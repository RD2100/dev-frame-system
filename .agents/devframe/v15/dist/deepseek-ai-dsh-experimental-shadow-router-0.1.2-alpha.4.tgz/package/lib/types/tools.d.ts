/**
 * The four model-facing Shadow tools and the whitelist installer. The Shadow
 * model face is exactly these routing tools plus any explicitly enabled user
 * memory access — never the host shell, raw session control, or unrestricted
 * MCP surface. Project developers and reviewers never receive them: the
 * installer registers into a scope only when the host designates that agent
 * as Shadow, and every tool re-checks the caller against the designation
 * before touching any state.
 * @module @deepseek-ai/dsh-experimental-shadow-router/tools
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ShadowRouter } from './service.ts';
/** The tool names the Shadow whitelist contributes, in registration order. */
export declare const SHADOW_TOOL_NAMES: readonly ["project_open", "project_send", "project_status", "project_stop"];
/**
 * Register exactly the four project tools into one Agent scope — the whole
 * Shadow whitelist contribution. Returns the scope-local disposer.
 * @param agent - The agent the host designated as Shadow.
 * @param _ctx - Mounting context; reserved for future cross-scope wiring.
 * @param router - The shadow router backing every tool call.
 * @returns the disposer removing all four registrations.
 */
export declare function installShadowTools(agent: Agent, _ctx: Context, router: ShadowRouter): () => void;
//# sourceMappingURL=tools.d.ts.map