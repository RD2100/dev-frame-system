/**
 * The shadow router (`ctx.shadowRouter`): the Cordis service that routes user
 * intent between independent project roots. It owns the durable controller
 * binding index (`shadow_router` domain: `bindings`, `deliveries`,
 * `requests`), the provisioning state machine with failure rollback, the
 * cross-root delivery persistence that keeps `received` and `completed` as
 * distinct durable states, the request deduplication ledger, and the
 * Shadow-only whitelist that installs the four project tools.
 *
 * Workspace facts (canonical identity, alias resolution) come from the native
 * workspace registry; controller role persistence comes from the
 * session-identity binding registry. Cross-root delivery does NOT reuse the
 * agent-team mailbox: unrelated root sessions are not teammates, and no
 * member-checking path is invoked. One workspace resolves to one current
 * controller; every mutation is serialized on one operation chain and written
 * through to the domain, so the tables stay the only durable authority.
 *
 * @module @deepseek-ai/dsh-experimental-shadow-router/service
 */
import z from '@deepseek-ai/schemastery';
import { Service, type Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import { WorkspaceId } from '@deepseek-ai/dsh-workspace';
import { ShadowMessageId } from './ids.ts';
import type { ShadowBindingRecord, ShadowBindingState, ShadowDeliveryMode, ShadowDeliveryRecord, ShadowDeliveryState } from './spec.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The mounted shadow router: binding store, delivery persistence, and the Shadow whitelist. */
        shadowRouter: ShadowRouter;
    }
}
/** Plugin config (all optional — `static Config` supplies the defaults). */
export interface ShadowRouterConfig {
    /**
     * Absolute directories a project root may live in. Fail-closed default: an
     * empty list authorizes nothing. Every entry must be an existing directory
     * at load, or activation fails loud.
     */
    authorizedRoots?: string[];
    /** Controller profile the host serves for project root sessions. */
    controllerProfile?: string;
    /**
     * Session id the host composition declares as its Shadow. The router
     * performs the real {@link ShadowRouter.markShadow} invocation itself at
     * the earliest resolvable point: immediately when that agent is already
     * live at activation, otherwise when it is created. An id that never
     * becomes live installs nothing (fail-closed, same as unconfigured);
     * marking is idempotent; disposal cleanup stays with the existing
     * `agent/disposed` effect.
     */
    shadowSessionId?: string;
    /** Per-workspace limit of pending (queued, not yet received) deliveries. */
    maxPendingDeliveries?: number;
    /** Maximum message text length in characters. */
    maxMessageChars?: number;
    /** Maximum projects (and delivery rows) returned by one status read. */
    statusPageSize?: number;
}
/** The receipt `project_open` returns: one workspace's controller association. */
export interface ProjectOpenResult {
    /** The workspace registry's stable project identity. */
    readonly workspaceId: WorkspaceId;
    /** The reserved (then actual) controller root session. */
    readonly controllerSessionId: SessionId;
    /** Association version after the open. */
    readonly bindingRevision: number;
    /** Provisioning state at return; `ready` is the usable one. */
    readonly state: ShadowBindingState;
    /** Canonical root the registry recorded. */
    readonly canonicalPath: string;
}
/**
 * The receipt `project_send` returns. `status` is `received`: durable target
 * acceptance of the input — never a claim that the work ran or succeeded.
 */
export interface ProjectSendResult {
    /** Stable delivery identity, derived from the request id. */
    readonly messageId: ShadowMessageId;
    /** Receiving project. */
    readonly workspaceId: WorkspaceId;
    /** The durable receipt state; always `received` at send time. */
    readonly status: 'received';
}
/** The receipt `project_stop` returns for one project's stop. */
export interface ProjectStopResult {
    /** The stopped project. */
    readonly workspaceId: WorkspaceId;
    /** `stopping` until the host confirms quiescence, then `stopped`. */
    readonly status: 'stopping' | 'stopped';
    /** Pending deliveries cancelled by this stop; they stay visible, never dropped. */
    readonly cancelledDeliveries: number;
    /** Association version after the stop. */
    readonly bindingRevision: number;
}
/** One bounded delivery row inside a status read. */
export interface ProjectDeliverySummary {
    /** Stable delivery identity. */
    readonly messageId: ShadowMessageId;
    /** Delivery mode. */
    readonly mode: ShadowDeliveryMode;
    /** Work ownership the delivery asserts. */
    readonly goalId: string;
    /** Durable delivery state; `received` is never read as `completed`. */
    readonly state: ShadowDeliveryState;
    /** ISO-8601 sender-intent instant. */
    readonly createdAt: string;
    /** ISO-8601 target-acceptance instant, when received. */
    readonly receivedAt?: string;
    /** ISO-8601 completion instant, when completed. */
    readonly completedAt?: string;
    /** Why the delivery was cancelled, when cancelled. */
    readonly cancelReason?: string;
}
/** One project row inside a status read. */
export interface ProjectStatusEntry {
    /** The workspace registry's stable project identity. */
    readonly workspaceId: WorkspaceId;
    /** Canonical root the registry recorded. */
    readonly canonicalPath: string;
    /** The current controller root session. */
    readonly controllerSessionId: SessionId;
    /** Whether the controller session is live in this process right now. */
    readonly controllerLive: boolean;
    /** Controller profile the binding pins. */
    readonly profileKey: string;
    /** Association version. */
    readonly bindingRevision: number;
    /** Provisioning/operation state. */
    readonly state: ShadowBindingState;
    /** Durable failure reason, when `needs_attention` or `failed`. */
    readonly failureReason?: string;
    /** The authorized open run's Goal, when one is recorded. */
    readonly activeGoalId?: string;
    /** What blocks the project, computed from durable state at read time. */
    readonly blockedReason?: string;
    /** First page of the project's deliveries, oldest first. */
    deliveries: ProjectDeliverySummary[];
    /** Whether more delivery rows exist beyond the bounded page. */
    readonly deliveriesTruncated: boolean;
}
/** The bounded, read-only result `project_status` returns. */
export interface ProjectStatusResult {
    /** One page of authorized projects. */
    projects: ProjectStatusEntry[];
    /** Offset of the next page, when more projects exist. */
    readonly nextCursor?: number;
    /** ISO-8601 instant the observation was taken. */
    readonly observedAt: string;
}
/** Host-level request shapes; the model-facing wrappers live in `tools.ts`. */
export interface ProjectOpenRequest {
    /** Existing, authorized root directory. */
    readonly path: string;
    /** Stable request id; replays return the prior result. */
    readonly requestId: string;
}
/** Host-level request to deliver one message into an authorized project. */
export interface ProjectSendRequest {
    /** Receiving project. */
    readonly workspaceId: string;
    /** Association version the sender asserts. */
    readonly bindingRevision: number;
    /** Work ownership the message asserts. */
    readonly goalId: string;
    /** Acceptance association the message asserts. */
    readonly acceptanceHash: string;
    /** Stable request id; retries reuse it. */
    readonly requestId: string;
    /** `work` schedules follow-up; `note` is quiet input. */
    readonly mode: ShadowDeliveryMode;
    /** Bounded message text. */
    readonly text: string;
}
/** Host-level request to stop one authorized project. */
export interface ProjectStopRequest {
    /** Project to stop. */
    readonly workspaceId: string;
    /** Association version the caller asserts. */
    readonly expectedRevision: number;
    /** Stable request id; replays return the prior result. */
    readonly requestId: string;
}
/** The shadow router: binding store, cross-root delivery, and the Shadow tool whitelist. */
export declare class ShadowRouter extends Service {
    static inject: string[];
    static Config: z<ShadowRouterConfig>;
    /** Validated config (schemastery applied the defaults before construction). */
    private readonly config;
    private bindingsTable?;
    private deliveriesTable?;
    private requestsTable?;
    private readonly bindings;
    private readonly deliveries;
    private readonly requests;
    /** Canonical authorized roots, resolved once at load; empty authorizes nothing. */
    private authorizedRoots;
    /** Session ids of host-designated Shadow sessions, mapped to their tool disposer. */
    private readonly shadowAgents;
    private tail;
    /**
     * @param ctx - Mounting context.
     * @param config - Schema-validated config; limits must be positive safe integers.
     */
    constructor(ctx: Context, config: ShadowRouterConfig);
    protected [Service.init](): Promise<void>;
    /** Canonicalize every authorized root; a missing or relative entry fails the load. */
    private validateAuthorizedRoots;
    /**
     * Cold-restore reconciliation for rows that were mid-provisioning when the
     * previous process ended. A reserved session that exists and matches the
     * row completes to `ready` (the bind is the role persistence); a mismatch
     * parks the project as `needs_attention`. A missing session stays as-is —
     * creating sessions during restore would be a side effect the host did not
     * ask for; the next `project_open` or {@link ShadowRouter.reconcileProject}
     * converges around the same reserved id.
     */
    private reconcileProvisioningOnRestore;
    /**
     * Designate one live agent as the host's Shadow and install the four
     * project tools — and nothing else — into its scope. The host chooses the
     * profile; workers, leads, and reviewers are never marked, and marking is
     * idempotent.
     * @param agent - The live agent the host designates as Shadow.
     */
    markShadow(agent: Agent): void;
    /**
     * Whether one agent is the designated Shadow.
     * @param agent - The agent to check, or `undefined` when the caller has no attached agent.
     * @returns true when the agent is currently designated as the host's Shadow; the predicate also narrows `agent` to `Agent`.
     */
    isShadow(agent: Agent | undefined): agent is Agent;
    /** The calling session must be the host-designated Shadow; the checked agent flows on. */
    private requireShadow;
    /**
     * Open (or resolve) one project: canonicalize and authorize the root, reuse
     * the workspace registry's identity, and converge the controller binding —
     * reserving a controller session id and persisting the in-creation
     * association before the session exists. Repeated opens deduplicate; a
     * request id replayed with different input conflicts.
     * @param caller - The designated Shadow session.
     * @param request - Existing authorized path and stable request id.
     * @returns the controller association.
     */
    openProject(caller: Agent | undefined, request: ProjectOpenRequest): Promise<ProjectOpenResult>;
    /**
     * Deliver one bounded message to a project's controller. The delivery is
     * persisted twice on purpose: first as the sender intent (`queued`), then as
     * the target-accepted input (`received`). The receipt never claims
     * completion; `completed` is a separate durable state the controller side
     * settles via {@link ShadowRouter.completeDelivery}.
     * @param caller - The designated Shadow session.
     * @param request - Target workspace, asserted revision and work ownership, mode, and text.
     * @returns the delivery receipt.
     */
    sendToProject(caller: Agent | undefined, request: ProjectSendRequest): Promise<ProjectSendResult>;
    /**
     * Stop one project in isolation: close its receiving, cancel its pending
     * deliveries (kept visible, never dropped), and park the binding in
     * `stopping` until the host confirms quiescence via
     * {@link ShadowRouter.confirmProjectStopped}. Other projects are untouched.
     * @param caller - The designated Shadow session.
     * @param request - Target workspace, asserted revision, and stable request id.
     * @returns the stop receipt.
     */
    stopProject(caller: Agent | undefined, request: ProjectStopRequest): Promise<ProjectStopResult>;
    /**
     * Read one project or one bounded page of projects. The read never mutates
     * durable state, never appends a session event, and never wakes a model;
     * every row carries the observation instant, and a `received` receipt is
     * reported verbatim instead of being read as completion.
     * @param caller - The designated Shadow session.
     * @param request - Optional workspace id plus bounded page controls.
     * @returns the observed status.
     */
    projectStatus(caller: Agent | undefined, request: {
        readonly workspaceId?: string;
        readonly cursor?: number;
        readonly limit?: number;
    }): Promise<ProjectStatusResult>;
    /**
     * Confirm one `stopping` project quiescent and finish its stop. The host
     * calls this once the project's own work has drained; no model tool does.
     * Already-stopped bindings resolve without writing.
     * @param workspaceId - The project whose stop completes.
     * @returns the stopped binding.
     */
    confirmProjectStopped(workspaceId: WorkspaceId): Promise<ShadowBindingRecord>;
    /**
     * Record the workspace's authorized open run. Deliveries may only arrive
     * while the asserted Goal/acceptance association matches this record, which
     * is what keeps a previous Goal's message out of the controller's current
     * Goal. The host (controller side) calls this; no model tool reaches it.
     * @param workspaceId - The project to authorize the run for.
     * @param goalId - The authorized Goal.
     * @param acceptanceHash - The authorized acceptance association.
     * @returns the updated binding.
     */
    setActiveGoal(workspaceId: WorkspaceId, goalId: string, acceptanceHash: string): Promise<ShadowBindingRecord>;
    /**
     * Settle one received delivery as completed. `completed` is a controller
     * side durable fact, distinct from the `received` receipt; the host calls
     * this, and no model tool does. A receiver that is `stopping` or `stopped`
     * cannot settle: the call rejects with `SHADOW_RECEIVER_CLOSED` and the row
     * stays `received`.
     * @param workspaceId - The project the delivery belongs to.
     * @param messageId - The delivery to settle.
     * @returns the updated delivery.
     */
    completeDelivery(workspaceId: WorkspaceId, messageId: ShadowMessageId): Promise<ShadowDeliveryRecord>;
    /**
     * Converge one workspace's queued deliveries after a restart or a Goal
     * switch: a still-authorized delivery becomes `received`; a stale one is
     * cancelled with a visible reason instead of being forwarded to a Goal it
     * was never bound to.
     * @param workspaceId - One project, or omitted for every project.
     * @returns the converged deliveries.
     */
    recoverDeliveries(workspaceId?: WorkspaceId): Promise<readonly ShadowDeliveryRecord[]>;
    /**
     * Converge one workspace's provisioning row around its reserved session id:
     * create the reserved session when it is still missing, complete the bind
     * when the session matches, and park mismatches as `needs_attention`. The
     * host calls this after a restart; `project_open` runs it implicitly.
     * @param workspaceId - The project to converge.
     * @returns the converged binding.
     */
    reconcileProject(workspaceId: WorkspaceId): Promise<ShadowBindingRecord>;
    /**
     * Read one binding from the restored index.
     * @param workspaceId - The project whose binding to read.
     * @returns the binding record, or `undefined` when the workspace has no binding.
     */
    findBinding(workspaceId: WorkspaceId): ShadowBindingRecord | undefined;
    /**
     * Read every binding in stable (createdAt, workspaceId) order.
     * @returns every binding record in the index.
     */
    listBindings(): readonly ShadowBindingRecord[];
    /**
     * Read every delivery of one project (or all projects), oldest first.
     * @param workspaceId - Limits the result to one project; omit it to read every recorded delivery.
     * @returns the matching delivery records in stable (createdAt, messageId) order.
     */
    listDeliveries(workspaceId?: WorkspaceId): readonly ShadowDeliveryRecord[];
    /** Serialize mutations so concurrent routing operations cannot interleave. */
    private enqueue;
    /** The workspace id from the tool boundary: validated here, branded by the registry's own factory. */
    private requireWorkspaceId;
    /** Require one non-empty trimmed field or fail loud. */
    private requireField;
    /** The binding, or a loud unknown-workspace failure. */
    private requireBinding;
    /** The delivery, or a loud unknown-delivery failure. */
    private requireDelivery;
    /** Deliveries are admitted only while the project is `ready`. */
    private requireAdmitting;
    /** Replay a stored result for one request id, or conflict on different input. */
    private replayRequest;
    /** Persist one successful request result for replay. */
    private storeRequest;
    /**
     * Converge an existing row: `ready` (and the profile pin) is returned as
     *-is, terminal rows are rejected, `failed` rows may re-provision after the
     * old reservation is proven gone, and mid-provisioning rows reconcile
     * around their reserved session id — never by minting a second writer.
     */
    private convergeBinding;
    /**
     * Reconcile one mid-provisioning or failed-with-live-reservation row around
     * its reserved controller session id: complete to `ready` when the session
     * matches the row, park it as `needs_attention` when it does not, and
     * create the still-missing session on the SAME reserved id otherwise.
     */
    private reconcileReserved;
    /** Reserve (or, after a failure, re-reserve) the binding row before any session exists. */
    private reserveBinding;
    /**
     * Run one fresh binding through its full provisioning: reserve, create the
     * reserved controller root session, persist the controller role, and land
     * `ready` — the same persistence order a crash-residue recovery follows.
     */
    private provisionNewBinding;
    /**
     * Run one provisioning attempt: mark the row in-creation, create the
     * reserved controller root session (never parented to Shadow), persist the
     * controller role through the session-identity registry, and only then save
     * `ready`. A creation failure rolls the row to a visible `failed` state.
     */
    private createControllerSession;
    /** Finish provisioning: persist the controller role and only then `ready`. */
    private completeProvisioning;
    /** Park one binding as `needs_attention`; the durable reason explains what the host must resolve. */
    private markNeedsAttention;
    /** Roll a failed provisioning attempt to a visible `failed` row. */
    private markFailed;
    /** Mark one queued delivery received (durable target acceptance). */
    private markDeliveryReceived;
    /** Assert a crashed delivery row carries the retried request's exact ownership. */
    private assertSameDelivery;
    /** Build one bounded status row from durable state plus live-session presence. */
    private projectEntry;
    /** Project one delivery row into its bounded summary. */
    private deliverySummary;
    /** Write one binding through to the durable table, then mirror it into the index. */
    private persistBinding;
    /** Write one delivery through to the durable table, then mirror it into the index. */
    private persistDelivery;
    /** Write one request result through to the durable table, then mirror it into the index. */
    private persistRequest;
    /** The opened bindings table; absent only before Service.init completed. */
    private requireBindingsTable;
    /** The opened deliveries table; absent only before Service.init completed. */
    private requireDeliveriesTable;
    /** The opened requests table; absent only before Service.init completed. */
    private requireRequestsTable;
}
//# sourceMappingURL=service.d.ts.map