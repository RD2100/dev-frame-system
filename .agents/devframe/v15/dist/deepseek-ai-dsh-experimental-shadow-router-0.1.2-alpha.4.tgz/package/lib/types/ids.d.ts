/** Branded cross-boundary identifiers owned by the shadow-router vocabulary. */
import { type Branded } from '@deepseek-ai/dsh-brand';
/**
 * One caller-issued routing request. The model reuses one stable value across
 * retries of the same logical request; the host keeps it out of the message
 * content. Same id plus identical normalized input replays the prior result;
 * the same id with different input is a `SHADOW_REQUEST_CONFLICT`.
 */
export type ShadowRequestId = Branded<'ShadowRequestId'>;
/**
 * One durable cross-root delivery. Derived deterministically from the
 * request id at first persistence (`msg-<requestId>`), so a retried request
 * converges on the same message identity and target-side deduplication keys
 * on the same row.
 */
export type ShadowMessageId = Branded<'ShadowMessageId'>;
/**
 * One caller-asserted acceptance association for a delivery. The value is an
 * opaque bounded token; matching it against the workspace's authorized open
 * run is what makes a `work` delivery schedulable and what keeps a previous
 * Goal's message from becoming input to the controller's current Goal.
 */
export type AcceptanceHash = Branded<'AcceptanceHash'>;
/**
 * Brand a validated request id.
 * @param value - Raw request id from the tool boundary.
 * @returns the same string, branded at compile time.
 * @throws {@link ShadowRouterError} with code `SHADOW_INVALID_REQUEST` when
 * the value is not a bounded URL-safe token.
 */
export declare function ShadowRequestId(value: string): ShadowRequestId;
/**
 * Brand a validated delivery message id.
 * @param value - Raw message id (`msg-<requestId>` as derived by the service).
 * @returns the same string, branded at compile time.
 * @throws {@link ShadowRouterError} with code `SHADOW_INVALID_REQUEST` when
 * the value is not a bounded URL-safe token.
 */
export declare function ShadowMessageId(value: string): ShadowMessageId;
/**
 * Brand a validated acceptance hash.
 * @param value - Raw acceptance association token from the tool boundary.
 * @returns the same string, branded at compile time.
 * @throws {@link ShadowRouterError} with code `SHADOW_INVALID_REQUEST` when
 * the value is not a bounded printable-ASCII token.
 */
export declare function AcceptanceHash(value: string): AcceptanceHash;
//# sourceMappingURL=ids.d.ts.map