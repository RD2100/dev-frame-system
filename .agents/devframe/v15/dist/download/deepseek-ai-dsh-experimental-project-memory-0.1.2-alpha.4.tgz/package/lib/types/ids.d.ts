/** Branded note identity and the stable id derivation for project-memory. */
import { type Branded } from '@deepseek-ai/dsh-brand';
/**
 * Identifies one memory note. The id is host-derived (never model-supplied)
 * from the note's namespace and source event reference, so a retry of the
 * same append lands on the same id and file. Ids are lowercase 64-hex
 * digests: the shape alone rejects traversal probes and path separators.
 */
export type NoteId = Branded<'MemoryNoteId'>;
/** The maximum source-reference byte length accepted at the durable boundary. */
export declare const MAX_SOURCE_REF_BYTES = 512;
/**
 * Validate a host-issued note id before applying its compile-time brand.
 * @param value - Candidate id, expected as the exact 64-hex digest shape.
 * @returns the same string, branded at compile time.
 * @throws {@link ProjectMemoryError} with code `MEMORY_INVALID_NOTE_ID`
 * when the value is not a lowercase 64-hex id (including traversal probes
 * such as `../x`, path separators, or uppercase hex).
 */
export declare function NoteId(value: string): NoteId;
/**
 * Validate a stable source event reference before it feeds id derivation or
 * durable note metadata.
 * @param value - Host-issued reference, e.g. a session/event identity.
 * @returns the same string, unchanged.
 * @throws {@link ProjectMemoryError} with code `MEMORY_INVALID_NOTE` when the
 * reference is empty, whitespace-only, padded, contains a NUL byte (the id
 * derivation separator), or exceeds 512 UTF-8 bytes.
 */
export declare function validateSourceRef(value: string): string;
/**
 * Derive the stable note id for one namespace and source event. The
 * derivation is deterministic: every retry of the same append derives the
 * same id, and different namespaces never collide on one file.
 * @param namespace - Relative namespace directory (`user` or
 *   `projects/<workspaceId>`), already validated.
 * @param sourceRef - Validated stable source event reference.
 * @returns the derived note id.
 */
export declare function deriveNoteId(namespace: string, sourceRef: string): NoteId;
//# sourceMappingURL=ids.d.ts.map