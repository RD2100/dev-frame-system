/**
 * Content screening for candidate note bodies: secret patterns, environment
 * dumps, and unsafe control characters. Screening reduces accidental
 * leakage; it is not a guarantee. Rejections name the matched rule only —
 * suspected secrets are never echoed into errors or logs.
 * @module @deepseek-ai/dsh-experimental-project-memory/screen
 */
/** Stable ids of the screening rules; safe to surface in errors and logs. */
export type ScreeningRuleId = 'private-key-block' | 'credential-assignment' | 'bearer-token' | 'aws-access-key' | 'github-token' | 'slack-token' | 'deepseek-api-key' | 'environment-dump' | 'control-characters' | 'unpaired-surrogate';
/**
 * Screen a candidate note body before it reaches the Vault.
 * @param body - Candidate body text.
 * @returns the matched rule id, or `undefined` when the body passes.
 */
export declare function screenNoteBody(body: string): ScreeningRuleId | undefined;
//# sourceMappingURL=screen.d.ts.map