/**
 * The project memory service: the three bounded tools (`memory_search`,
 * `memory_read`, `memory_append`) over a real filesystem Vault subtree.
 *
 * Append is create-only and idempotent: note ids derive from namespace and
 * source event, retries keep the candidate body, a committed receipt is
 * checked before any create, and the receipt is durable before `created` is
 * returned. Reads verify the full file against the receipt, so externally
 * edited notes are reported (`memory_changed`) instead of silently recalled.
 * Permission errors, conflicts, and incomplete notes are never retried;
 * transient failures follow the bounded retry policy.
 *
 * @module @deepseek-ai/dsh-experimental-project-memory/memory
 */
import type { MemoryAppendRequest, MemoryAppendResult, MemoryReadRequest, MemoryReadResult, MemoryReceiptStore, MemoryRetryPolicy, MemorySearchRequest, MemorySearchResult, MemorySpec } from './types.ts';
/** The receipt store seam supplied by the host at construction. */
export type ProjectMemoryReceipts = MemoryReceiptStore;
/**
 * Classify a filesystem failure for the bounded retry policy: `conflict`
 * errors propagate raw for create-only handling, `permanent` errors fail
 * immediately, everything else (including unknown codes) is transient.
 * Exported for the bounded-retry behavior tests.
 * @param error - The caught filesystem failure.
 * @returns the retry classification of the failure.
 */
export declare function classifyFsError(error: unknown): 'transient' | 'conflict' | 'permanent';
/**
 * Run one filesystem operation under the bounded retry policy. `conflict`
 * errors are rethrown raw (the caller distinguishes create races);
 * `ProjectMemoryError` passes through untouched. Exported for the
 * bounded-retry behavior tests.
 * @param policy - The configured attempt count and backoff schedule.
 * @param label - Operation label used in the wrapped failure message.
 * @param code - Explicit failure code the operation's errors map onto.
 * @param operation - The filesystem operation to run.
 * @returns the operation's first successful result.
 */
export declare function withRetry<T>(policy: MemoryRetryPolicy, label: string, code: 'MEMORY_WRITE_FAILED' | 'MEMORY_UNAVAILABLE', operation: () => Promise<T>): Promise<T>;
/**
 * The project memory service. One instance is bound to one calling session's
 * workspace identity and allowed scopes; construct it with a spec resolved
 * by `resolveMemorySpec` and a host-owned receipt store.
 */
export declare class ProjectMemoryService {
    private readonly spec;
    private readonly receipts;
    /**
     * @param spec - Resolved service spec (vault root, consent, limits, retry).
     * @param receipts - Receipt store seam; the host implements it over the
     *   DSH session log so receipts survive restarts.
     */
    constructor(spec: MemorySpec, receipts: ProjectMemoryReceipts);
    /** The allowed namespaces: user memory only when explicitly enabled. */
    private assertScope;
    /** The Vault root realpath, or an explicit `MEMORY_UNAVAILABLE` failure. */
    private requireVaultRoot;
    /** The namespace directory of one scope, relative to the Vault root. */
    private namespace;
    /** Read one receipt, failing loud when the seam is unusable. */
    private readReceipt;
    /** Commit one receipt; a failure here leaves the note file unconfirmed. */
    private writeReceipt;
    /** Read a note file under the bounded retry policy. */
    private readNoteFile;
    /**
     * Read a note for append-path evaluation, allowing a bounded stabilization
     * window: a concurrent writer of the same derived path may still be
     * flushing when the exclusive create loses its race, and that in-flight
     * write must not be misreported as an interrupted (incomplete) note. A
     * genuinely interrupted write stays incomplete after the window and is
     * then reported for explicit repair.
     */
    private readExistingForAppend;
    /**
     * Verify a complete note's file against its committed receipt.
     * @returns `true` (verified), `false` (receipt disagrees), or `null` (no receipt).
     */
    private verifyReceipt;
    /**
     * Search one allowed namespace: deterministic filename order, bounded
     * candidate scan, bounded text matching, and explicit partial-coverage
     * reporting. Scope checks run before any note content is read; notes that
     * disagree with their receipt, are incomplete, or are superseded inside
     * the same namespace are excluded from automatic recall.
     * @param request - Scope, query text, and optional result cap.
     * @returns the bounded hits with coverage and truncation facts.
     */
    search(request: MemorySearchRequest): Promise<MemorySearchResult>;
    /**
     * Read one note by host-issued id within one allowed namespace. Unknown
     * ids, missing files, changed files, and incomplete files are each
     * reported honestly; nothing is chased across namespaces.
     * @param request - Scope and the host-issued note id.
     * @returns the honest read outcome for the note.
     */
    read(request: MemoryReadRequest): Promise<MemoryReadResult>;
    /**
     * Append one note: validate, screen, derive the stable id, check the
     * committed receipt, then create the file exclusively and commit the
     * receipt before returning `created`. The candidate body is never
     * regenerated; conflicting or externally changed files are never modified.
     * @param request - Scope, stable source reference, kind, candidate body,
     *   assertion status, optional snapshot, and optional superseded note.
     * @returns the append outcome with the note id and expected path.
     */
    append(request: MemoryAppendRequest): Promise<MemoryAppendResult>;
    /**
     * Exclusively create and flush one note file. The namespace directory is
     * created on demand; an `EEXIST` from the create-only open reports
     * `'exists'` so the caller re-evaluates the path instead of overwriting.
     */
    private createNoteFile;
}
//# sourceMappingURL=memory.d.ts.map