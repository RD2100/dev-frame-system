/**
 * Vault layout and path containment: namespace derivation, safe workspace
 * segments, symlink/reparse rejection, and note path resolution inside the
 * user-selected Vault root. The service manages only the
 * `<vault>/devframe-memory/` subtree and never creates the Vault root.
 * @module @deepseek-ai/dsh-experimental-project-memory/vault
 */
import type { NoteId } from './ids.ts';
import type { MemoryNamespace, MemoryScope } from './types.ts';
/** The dedicated DevFrame-managed subtree inside the user's Vault. */
export declare const MEMORY_DIR = "devframe-memory";
/**
 * Validate that a value is safe to use as exactly one path segment on every
 * supported filesystem: no separators, traversal, control characters,
 * trailing dot/space, or Windows reserved device name.
 * @param value - Candidate segment.
 * @returns the same string, unchanged.
 * @throws {@link ProjectMemoryError} with code `MEMORY_INVALID_WORKSPACE_ID`
 * when the value is unsafe.
 */
export declare function validateWorkspaceSegment(value: string): string;
/**
 * Resolve the relative namespace directory for one scope. The project
 * namespace isolates workspaces from each other; the user namespace is the
 * explicitly allowed user memory directory.
 * @param scope - The requested scope.
 * @param workspaceId - Validated workspace segment.
 * @returns the relative namespace directory.
 */
export declare function namespaceOf(scope: MemoryScope, workspaceId: string): MemoryNamespace;
/**
 * The note's expected path relative to the Vault root, as recorded in its
 * receipt.
 * @param namespace - Relative namespace directory.
 * @param noteId - Derived note id.
 * @returns e.g. `devframe-memory/user/<id>.md`.
 */
export declare function noteRelativePath(namespace: MemoryNamespace, noteId: NoteId): string;
/**
 * Resolve one note's absolute file path inside the Vault, rejecting
 * traversal (by id shape, upstream), unexpected symlink components, and any
 * resolution that escapes the Vault root.
 * @param rootReal - Realpath of the Vault root.
 * @param namespace - Relative namespace directory.
 * @param noteId - Derived, host-issued note id.
 * @returns the absolute path and whether a (non-symlink) file exists there.
 */
export declare function resolveNoteFilePath(rootReal: string, namespace: MemoryNamespace, noteId: NoteId): Promise<{
    readonly path: string;
    readonly exists: boolean;
}>;
/**
 * Create the namespace directory (and the `devframe-memory` subtree) if
 * missing, then verify its real path stays inside the Vault root.
 * @param rootReal - Realpath of the Vault root.
 * @param namespace - Relative namespace directory.
 * @returns the absolute namespace directory path.
 * @throws {@link ProjectMemoryError} with code `MEMORY_WRITE_FAILED` when the
 * directory cannot be created, or `MEMORY_PATH_REJECTED` when the created
 * directory resolves outside the Vault root.
 */
export declare function ensureNamespaceDir(rootReal: string, namespace: MemoryNamespace): Promise<string>;
//# sourceMappingURL=vault.d.ts.map