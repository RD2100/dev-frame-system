/** Explicit spec resolution for the project-memory service boundary. */
import type { MemoryLimits, MemoryRetryPolicy, MemorySpec } from './types.ts';
/** The documented initial limits of `docs/detailDesign-part3.md` (tools section). */
export declare const DEFAULT_MEMORY_LIMITS: MemoryLimits;
/** The documented initial retry policy of `docs/detailDesign-part4.md` (limits section). */
export declare const DEFAULT_MEMORY_RETRY: MemoryRetryPolicy;
/** Caller-facing request for spec resolution; every field may be defaulted. */
export interface MemorySpecRequest {
    /** The user-selected Vault root; omitted when memory is not configured. */
    readonly vaultRoot?: string;
    /** Whether the user enabled appends; defaults to `false` (read-only). */
    readonly writeEnabled?: boolean;
    /** Whether user-scope memory is explicitly allowed; defaults to `false`. */
    readonly userScopeEnabled?: boolean;
    /** Host-derived native workspace identity of the calling session. */
    readonly workspaceId: string;
    /** Host-derived current project snapshot, when known. */
    readonly currentSnapshot?: string;
    /** Limit overrides; each missing field keeps the documented default. */
    readonly limits?: Partial<MemoryLimits>;
    /** Retry overrides; each missing field keeps the documented default. */
    readonly retry?: Partial<MemoryRetryPolicy>;
}
/**
 * Resolve the service spec explicitly at the package boundary: every default
 * is applied here, and `ProjectMemoryService` performs no hidden fallbacks.
 * @param request - Caller-facing configuration request.
 * @returns the resolved spec.
 * @throws {@link ProjectMemoryError} with code `MEMORY_INVALID_WORKSPACE_ID`
 * when the workspace id is not a safe path segment, or
 * `MEMORY_INVALID_REQUEST` when a limit or retry override is malformed.
 */
export declare function resolveMemorySpec(request: MemorySpecRequest): MemorySpec;
//# sourceMappingURL=config.d.ts.map