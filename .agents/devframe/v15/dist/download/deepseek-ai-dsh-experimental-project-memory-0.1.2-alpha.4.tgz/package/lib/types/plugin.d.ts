/**
 * Cordis plugin wiring for the project-memory service: one loadable entry that
 * resolves the memory spec from validated config, provides `ctx.projectMemory`,
 * and registers the three bounded memory tools of `docs/detailDesign-part3.md`
 * on `ctx.tools`. The model tool surface derives assertion status here — tools
 * record observations; `confirmed` user preferences stay reachable only
 * through the host's own human-confirmation flow.
 * @module @deepseek-ai/dsh-experimental-project-memory/plugin
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import { ProjectMemoryService } from './memory.ts';
import type { MemoryReceiptStore, MemorySpec } from './types.ts';
/** Cordis plugin name. */
export declare const name = "project-memory";
/** Services required by the project-memory plugin. */
export declare const inject: string[];
/** Load configuration for the project-memory plugin. */
export interface Config {
    /**
     * The user-selected Obsidian Vault root. Omit to keep memory unconfigured:
     * the tools then report `MEMORY_UNAVAILABLE` instead of touching any path.
     */
    readonly vaultRoot?: string;
    /** Whether the user enabled appends; `false` keeps memory read-only. */
    readonly writeEnabled?: boolean;
    /** Whether user-scope memory is allowed for this deployment. */
    readonly userScopeEnabled?: boolean;
    /** Host-derived native workspace identity of the calling sessions. */
    readonly workspaceId?: string;
    /** Host-derived current project snapshot for staleness marking. */
    readonly currentSnapshot?: string;
}
/**
 * Loader schema. `workspaceId` is required at load; the object-schema input
 * type cannot express that requiredness, so the declaration is cast.
 */
export declare const Config: z<Config>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The bounded project-memory service built from this plugin's config. */
        projectMemory: ProjectMemoryService;
    }
}
/**
 * Build the three memory tool definitions bound to one service instance.
 * @param service - The process-wide memory service the tools dispatch to.
 * @param spec - The resolved spec the tool policy reads (current snapshot).
 * @param receipts - The process-wide receipt index the append tool reads the
 *   committed receipt from before logging it into the calling session.
 * @returns the registry-ready tool definitions.
 */
export declare function createMemoryTools(service: ProjectMemoryService, spec: MemorySpec, receipts: MemoryReceiptStore): ToolDefinition[];
/**
 * Plugin entry: resolve the spec, provide the service, register the tools.
 * Misconfiguration fails loud at load — the loader schema rejects a missing
 * workspace id, and the plugin refuses write consent without a Vault root.
 *
 * Receipt durability: the service commits each receipt into a process-wide
 * index; the `memory_append` tool then writes the same receipt into the
 * calling agent's session log before the tool result is created. Every
 * agent created after mount rehydrates the index by folding that agent's
 * session log, so a cold restart recovers the receipts from replayed logs.
 * @param ctx - the mounting context.
 * @param config - validated loader config.
 * @returns the plugin disposer.
 */
export declare function apply(ctx: Context, config: Config): () => void;
//# sourceMappingURL=plugin.d.ts.map