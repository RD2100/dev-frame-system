/** The in-memory receipt store used by tests and as the seam reference. */
import type { MemoryReceipt, MemoryReceiptStore } from './types.ts';
/**
 * Create an in-memory {@link MemoryReceiptStore}. The durable implementation
 * belongs to the host (receipts must live in the DSH session log before an
 * append returns `created`); this store exists for tests and for callers
 * that assemble the seam from an already-restored receipt list.
 * @param entries - Receipts restored from the session log, rehydrating the
 *   store for a cold service start.
 * @returns the store, backed by a plain map keyed by note id.
 */
export declare function createMemoryReceiptStore(entries?: readonly MemoryReceipt[]): MemoryReceiptStore;
//# sourceMappingURL=receipt.d.ts.map