/**
 * Note file serialization, strict parsing, digests, and UTF-8 byte
 * utilities. The file format is a fixed-key front matter block plus the body;
 * a `bodyDigest` in the front matter identifies the exact stored body so an
 * interrupted write is distinguishable from a complete note.
 * @module @deepseek-ai/dsh-experimental-project-memory/notes
 */
import { type MemoryNote, type MemoryNoteMeta } from './types.ts';
import { NoteId } from './ids.ts';
import type { MemoryNamespace } from './types.ts';
/**
 * SHA-256 of the UTF-8 encoding of one string, as lowercase hex.
 * @param value - String to digest.
 * @returns the lowercase hex digest.
 */
export declare function sha256Hex(value: string): string;
/**
 * `sha256:<hex>` digest of one UTF-8 string, as stored in notes and receipts.
 * @param value - String to digest.
 * @returns the tagged digest.
 */
export declare function digestTag(value: string): string;
/**
 * UTF-8 byte length of one string.
 * @param value - String to measure.
 * @returns the UTF-8 byte length.
 */
export declare function utf8ByteLength(value: string): number;
/**
 * Truncate a string to at most `maxBytes` UTF-8 bytes, dropping whole code
 * points only, so the result never ends inside a multi-byte sequence or a
 * surrogate pair.
 * @param value - String to truncate.
 * @param maxBytes - Byte ceiling.
 * @returns the longest prefix that fits, with every code point intact.
 */
export declare function truncateToByteLimit(value: string, maxBytes: number): string;
/** Why a file is not a self-consistent complete note. */
export type NoteParseFailure = {
    readonly reason: 'structure';
    readonly detail: string;
} | {
    readonly reason: 'body-digest';
    readonly detail: string;
};
/** Success or failure of parsing one note file's contents. */
export type NoteParseResult = {
    readonly ok: true;
    readonly meta: MemoryNoteMeta;
    readonly body: string;
} | {
    readonly ok: false;
    readonly failure: NoteParseFailure;
};
/**
 * Serialize one note to its durable file contents: fixed-order front matter,
 * a blank line, then the body stored verbatim (no terminator is added, so
 * the body digest survives the round trip exactly). Deterministic for
 * identical metadata and body.
 * @param meta - Host-derived note metadata; `bodyDigest` must match `body`.
 * @param body - The exact body text to store.
 * @returns the full file contents.
 */
export declare function serializeNote(meta: MemoryNoteMeta, body: string): string;
/**
 * Build the host-derived metadata for one candidate note.
 * @param args - Derived id, resolved namespace, request fields, and body.
 * @returns the metadata with `createdAt` stamped to now and `bodyDigest`
 *   computed over the body.
 */
export declare function buildNoteMeta(args: {
    readonly noteId: NoteId;
    readonly namespace: MemoryNamespace;
    readonly kind: MemoryNoteMeta['kind'];
    readonly status: MemoryNoteMeta['status'];
    readonly source: string;
    readonly snapshot: string | undefined;
    readonly supersedes: NoteId | undefined;
    readonly body: string;
}): MemoryNoteMeta;
/**
 * Parse one note file's contents strictly. Structural failures and body
 * digest mismatches both mean the file is not a self-consistent complete
 * note; callers preserve it and report `incomplete_note` — a digest mismatch
 * proves a change or truncation, never which.
 * @param contents - Full file contents as UTF-8 text.
 * @returns the parsed note, or the parse failure.
 */
export declare function parseNote(contents: string): NoteParseResult;
/**
 * Compare a complete existing note against a candidate append: retries and
 * lost concurrent races match on every host-derived field and the body
 * digest, while `createdAt` (stamped once at create) is deliberately not
 * compared.
 * @param existing - The parsed note occupying the derived path.
 * @param candidate - The candidate note for the same derived path.
 * @returns `true` when both record the same note content.
 */
export declare function sameNoteContent(existing: MemoryNote, candidate: MemoryNote): boolean;
//# sourceMappingURL=notes.d.ts.map